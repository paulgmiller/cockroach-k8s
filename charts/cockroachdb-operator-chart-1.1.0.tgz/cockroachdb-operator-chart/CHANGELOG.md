# CockroachDB Operator Chart — CHANGELOG

<!-- For new releases, separate Helm installations, Non-Helm installations,
and shared Operator behavior when those categories apply. -->

## [1.1.0] — 2026-09-21

### Helm installations

#### Changed
- Updated the default operator image to `docker.io/cockroachdb/cockroachdb-operator-v2:v1.1.0`.

### Non-Helm installations

#### Changed
- Updated the rendered operator bundle to use the `v1.1.0` operator and related images.

### Operator behavior

#### Fixed
- Fixed cluster initialization attempts that could hang indefinitely and block reconciliation of
  other `CrdbCluster` resources. Initialization now times out and retries without blocking other
  clusters, with failures surfaced through status, events, and logs.
- Fixed an issue with cluster-scoped PriorityClasses that caused repeated patches and
  `OwnerRefInvalidNamespace` warnings when multiple `CrdbCluster` resources were installed in the
  same Kubernetes cluster. PriorityClasses no longer receive `CrdbCluster` owner references, and
  stale references are removed during reconciliation.
- Fixed rolling operations that could stall when the under-replicated ranges check selected a
  running but unready pod. The check now uses a ready pod.
- Fixed WAL volume size changes triggering CockroachDB pod restarts. Existing node revision hashes
  are updated without restarting healthy pods.
- Fixed the operator continuing with an empty cloud region when node metadata lookup fails. The
  operator now falls back to `CLOUD_REGION` and exits with an error when no region can be resolved.
- Fixed topology-aware scale-down for clusters that configure `topologySpreadConstraints` through
  `podTemplate`. The operator now derives topology information from the effective rendered Pod and
  refreshes it when Kubernetes Node labels change.
- Fixed migration conversion webhook TLS failures after operator certificate rotation. The operator
  now keeps the `CrdbCluster` CRD conversion webhook CA bundle synchronized without requiring a
  restart.

### Upgrade Notes
- The `cockroachdb-parent-25.3.4-preview+1` release moved `topologySpreadConstraints` from the
  deprecated first-class field to `podTemplate`. Operators earlier than `v1.1.0` still require the
  first-class field for topology-aware scale-down. Users running that or a later chart with an
  earlier operator must temporarily restore the field in both `values.yaml` and
  `templates/crdb.yaml` and keep it present through every Helm operation until the operator is
  upgraded. Configuring `podTemplate.spec.topologySpreadConstraints` is optional; if both fields
  are configured, keep their constraints equivalent.

See [Topology spread constraints with operators before v1.1.0](../cockroachdb/README.md#topology-spread-constraints-with-operators-before-v110)
for the Helm configuration and temporary compatibility steps.

## [1.0.0] — 2026-08-05

### Helm installations

#### Changed
- Promoted the operator chart and default operator image from `1.0.0-rc.4` to the
  `1.0.0` general availability release.
- Updated the [Helm 4 Server-Side Apply documentation](README.md#helm-4-server-side-apply).

### Non-Helm installations

#### Changed
- Updated the rendered operator bundle to use the `v1.0.0` operator and related images.

### Operator behavior

#### Fixed
- Fixed Server-Side Apply ownership conflicts for non-migration clusters when migration is
  enabled. Fresh and completed v1beta1 clusters remain operable and can be upgraded while other
  clusters are migrating or the public and CockroachDB operators coexist.
- Skipped the under-replicated ranges health check for single-node clusters so rolling updates
  and other operations can proceed when replication targets cannot be satisfied.

## [1.0.0-rc.4] — 2026-07-31

### Helm installations

#### Changed
- Updated the default operator image to `docker.io/cockroachdb/cockroachdb-operator-v2:v1.0.0-rc.4`.
- Documented Helm 4 server-side apply field ownership conflicts, client-side apply compatibility,
  and the reviewed use of `--force-conflicts`.

### Non-Helm installations

#### Added
- Published standalone `CrdbCluster` and `CrdbNode` CRD manifests for non-Helm and GitOps
  installations.
- Added a public `v1beta1` API reference, a rendered Kubernetes bundle, and directly applicable
  `CrdbCluster` examples for non-Helm installations.

### Operator behavior

#### Added
- Added structured pod-restart reason and specification-change logging to improve visibility into
  unexpected restarts and rolling updates.

#### Fixed
- Fixed webhook TLS certificate mismatches after the operator certificate Secret is updated,
  without requiring a manual operator restart.
- Fixed under-replicated range health checks on UA clusters so rolling upgrades and scaling
  operations are not incorrectly blocked.
- Fixed rolling updates that could stall when the operator restarts while an update is in
  progress.
- Fixed an edge case where an operator restart or concurrent specification change during a
  scale-down could prevent the operation from completing.
- Fixed an edge case where a PVC resize could block pod recovery and prevent the resize from
  completing.

## [1.0.0-rc.3] — 2026-07-23
### Added
- Added support for `spec.postInitSQL` on `CrdbCluster` to run raw SQL once after cluster
  initialization. The CockroachDB chart exposes it through
  `cockroachdb.crdbCluster.postInitSQL`; see
  [Post-Init SQL](../cockroachdb/README.md#post-init-sql).
- Added an under-replicated ranges gate for rolling restarts and scale-downs; see
  [Under-Replicated Ranges Check](README.md#under-replicated-ranges-check).

### Changed
- Updated the default operator image to `docker.io/cockroachdb/cockroachdb-operator-v2:v1.0.0-rc.3`.
- Added the `update` RBAC verb for `batch/jobs` so the operator can update Jobs.

## [1.0.0-rc.2] — 2026-05-25
### Added
- Support for automated migration from Helm-managed StatefulSet clusters and Public Operator
  `v1alpha1` clusters to CockroachDB Operator `v1beta1` clusters. Use the operator chart's
  `migration.enabled=true` flag only for these migration flows and follow the controller
  migration guides in [docs/migration](../../../docs/migration). Preview customers upgrading
  existing CockroachDB Operator deployments do not need to enable this flag.
- Support for CMEK rotation in operator-managed CockroachDB clusters.
- Optional `nodeReader` RBAC support for split-chart installations. Platform teams can use the
  operator chart to pre-create the shared node-reader ClusterRole/ClusterRoleBinding for tenant
  CockroachDB pod ServiceAccounts, then tenants can disable node-reader RBAC creation in the
  CockroachDB chart.

### Changed
- Updated the default operator image to `docker.io/cockroachdb/cockroachdb-operator-v2:v1.0.0-rc.2`.

### Fixed
- Fixed version validation when version checker job pods are garbage-collected quickly.

### Upgrade Notes
- Recommended upgrade path: upgrade to `cockroachdb-operator-chart` `1.0.0-rc.1` first, verify
  that the `crdbclusters.crdb.cockroachlabs.com` CRD serves `v1beta1`, stores `v1beta1`, and has
  completed storage migration with `status.storedVersions` set to `["v1beta1"]`, then upgrade to
  `1.0.0-rc.2`.
  **Note:** Preview customers upgrading existing CockroachDB Operator deployments do not need to
  set `migration.enabled=true`. That flag is only for automated Helm StatefulSet and Public
  Operator migration flows. Migrated Public Operator clusters may continue using v1alpha1 until
  the CRD `storedVersions` is patched. Follow the controller migration guides in
  [docs/migration](../../../docs/migration) for when to patch `storedVersions` and disable
  migration mode.
- The operator chart no longer includes pre-upgrade validation hooks. Before upgrading, use the
  verification commands in [MIGRATION_v1alpha1_to_v1beta1.md](../../MIGRATION_v1alpha1_to_v1beta1.md)
  to confirm the cluster is already in the fully migrated `v1beta1` state.

## [1.0.0-rc.1] — 2026-05-06
### Changed
- **Per-chart versioning**: The operator chart now uses independent semantic versioning, starting
  at 1.0.0-rc.1. A single operator version supports multiple CockroachDB versions.
- **Chart name**: The chart name is `cockroachdb-operator-chart` for published Helm and OCI
  artifacts. Rendered Kubernetes names remain based on `cockroachdb-operator`.
- **Image tags**: The operator image now uses semantic version tags (`v1.0.0-rc.1`) instead of
  SHA digests.
- **Image registry**: The operator image now defaults to DockerHub (`docker.io/cockroachdb`)
  instead of Google Artifact Registry.

### Upgrade Notes
- Users must be on the latest preview version (`26.1.3-preview+1`) before upgrading.
- `helm upgrade <release> cockroachdb-v2/cockroachdb-operator-chart --version 1.0.0-rc.1`
- See [VERSIONING.md](../../docs/VERSIONING.md) for upstream Helm repository and OCI locations.

### Previous releases
For changes prior to per-chart versioning, see the [root CHANGELOG](../../../CHANGELOG.md).
